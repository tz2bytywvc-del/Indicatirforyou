export default async () => new Response(JSON.stringify({ ok: true, configured: !!String(process.env.TWELVE_DATA_API_KEY || '').trim() }), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
export const config = { path: '/api/status' };
