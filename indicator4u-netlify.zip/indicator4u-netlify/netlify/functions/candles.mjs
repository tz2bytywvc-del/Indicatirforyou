/*
 * GET /api/candles?symbol=EUR/USD&interval=5m   -> Twelve Data candles (Netlify Function)
 * The key comes from the TWELVE_DATA_API_KEY environment variable set in Netlify. It is never sent to browsers.
 */
import lib from '../../lib/market.js';
const { createMarket, INTERVALS } = lib;

let market;       // kept between calls while the function instance stays warm (small in-memory cache)
function get() {
  if (!market) {
    market = createMarket({
      apiKey: String(process.env.TWELVE_DATA_API_KEY || '').trim(),
      baseUrl: process.env.TWELVE_DATA_BASE_URL || 'https://api.twelvedata.com',
      rpm: Number(process.env.TWELVE_DATA_RPM) || 8,
      daily: Number(process.env.TWELVE_DATA_DAILY) || 800,
    });
  }
  return market;
}

export default async (req) => {
  const h = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  if (req.method !== 'GET') return new Response(JSON.stringify({ ok: false, error: { type: 'bad_request', message: 'GET only.' } }), { status: 405, headers: h });
  const u = new URL(req.url);
  let r;
  try { r = await get().candles(u.searchParams.get('symbol'), u.searchParams.get('interval')); }
  catch (e) { console.error('candles failed:', e && e.message); return new Response(JSON.stringify({ ok: false, error: { type: 'upstream', message: 'Unexpected server error.' } }), { status: 500, headers: h }); }
  const b = r.body;
  if (b && b.error && b.error.retryAfter) h['Retry-After'] = String(b.error.retryAfter);
  // Let Netlify's CDN share good answers between all visitors; this is what protects your Twelve Data limits.
  if (r.status === 200 && b.ok && !b.stale && INTERVALS[b.interval]) h['Netlify-CDN-Cache-Control'] = 'public, s-maxage=' + INTERVALS[b.interval].ttl + ', stale-while-revalidate=30';
  return new Response(JSON.stringify(b), { status: r.status, headers: h });
};

export const config = { path: '/api/candles' };
