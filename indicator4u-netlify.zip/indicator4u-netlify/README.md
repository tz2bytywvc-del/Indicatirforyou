# indicator4u AI on Netlify

`public/index.html` is your site. `netlify/functions/candles.mjs` is the backend that calls Twelve Data. The key lives only in Netlify's settings.

## Deploy (Git or CLI; drag-and-drop may not include functions)

**With GitHub:** push this folder to a repository → Netlify → Add new site → Import from Git. Leave build command empty; publish directory `public` (already in netlify.toml).

**With the CLI:** `npm i -g netlify-cli`, `netlify login`, `netlify init` (or `netlify deploy --prod` after linking).

## Add the key (required)

Netlify → Site configuration → Environment variables → Add variable
`TWELVE_DATA_API_KEY` = your key (mark it **Secret** / "contains secret values"), scopes: **Functions** (and Runtime). Then **Deploy → Trigger deploy** so it takes effect.

Check: open `https://YOUR-SITE.netlify.app/api/status` → `"configured": true`.

## Limits on Netlify

The function shares good answers through Netlify's CDN (20 s for M1 up to 240 s for H4), so many visitors cost few Twelve Data credits. The free Twelve Data plan allows 8 calls/min across everything; when it is hit, the page shows the "API limit" state and keeps the last data labelled NOT LIVE.
Never commit a `.env` file. Do not put the key in `index.html`.
